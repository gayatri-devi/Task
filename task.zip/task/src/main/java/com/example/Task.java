package com.example;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class Task {
    private static final int MIN_OCTAVE = -3;
    private static final int MAX_OCTAVE = 5;
    private static final int NOTES_PER_OCTAVE = 12;

    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("Usage: java -jar task.jar <inputFile> <semitone> <outputFile>");
            return;
        }

        String inputFile = args[0];
        int semitone;
        try {
            semitone = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("Invalid semitone value. It must be an integer.");
            return;
        }
        String outputFile = args[2];

        try {
            ObjectMapper mapper = new ObjectMapper();
            List<int[]> notes = mapper.readValue(new File(inputFile), new TypeReference<List<int[]>>() {});

            for (int[] note : notes) {
                if (!transpose(note, semitone)) {
                    System.out.println("Error: Note out of range after transposition.");
                    return;
                }
            }

            mapper.writeValue(new File(outputFile), notes);
            System.out.println("Transposition completed successfully.");
        } catch (IOException e) {
            System.out.println("Error reading or writing files: " + e.getMessage());
        }
    }

    private static boolean transpose(int[] note, int semitone) {
        int octave = note[0];
        int noteNumber = note[1];

        int totalSemitones = octave * NOTES_PER_OCTAVE + noteNumber + semitone;
        int newOctave = totalSemitones / NOTES_PER_OCTAVE;
        int newNoteNumber = totalSemitones % NOTES_PER_OCTAVE;

        if (newNoteNumber < 0) {
            newNoteNumber += NOTES_PER_OCTAVE;
            newOctave--;
        }

        if (newOctave < MIN_OCTAVE || newOctave > MAX_OCTAVE || (newOctave == MAX_OCTAVE && newNoteNumber > 1)) {
            return false;
        }

        note[0] = newOctave;
        note[1] = newNoteNumber;
        return true;
    }
}
